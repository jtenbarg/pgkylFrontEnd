import numpy as np
import csv

def setConst(var):

    n = []
    paramFile = var.filenameBase + 'params.txt'
    with open(paramFile) as csv_file:
        csv_reader = csv.reader(csv_file, delimiter=',')
        line_count = 0
        for row in csv_reader:
            if line_count == 1:
                eps0 = float(row[0])
                mu0 = float(row[1])
                B0 = float(row[2])
                var.dimsX = int(row[3])
                var.dimsV = int(row[4])
                var.po = int(row[5])
                var.basis = row[6]
                var.model = row[7]
            elif line_count > 2:
                var.speciesFileIndex.append(row[0])
                var.mu.append(float(row[1]))
                var.q.append(float(row[2]))
                var.temp.append(float(row[3]))
                n.append(float(row[4]))
            line_count += 1

    var.mu0 = mu0
    var.eps0 = eps0
    var.c = 1 / np.sqrt(mu0*eps0)
    var.vA =  B0 / np.sqrt(np.multiply(n, var.mu) * mu0)
    var.vt =  np.sqrt(2.*np.divide(var.temp, var.mu))
    var.omegaP = np.sqrt(np.divide( np.multiply( np.multiply(var.q,var.q), n), var.mu)/eps0)
    var.omegaC = np.divide(np.absolute(var.q)*B0, var.mu)
    var.d = np.divide(var.c, var.omegaP)
    var.debye = np.divide(var.vt, var.omegaP) / np.sqrt(2.)

    if B0 != 0.:
        var.beta = 2.*mu0*np.multiply(n,var.temp) / (B0*B0 )
        var.rho = np.divide(var.vt, var.omegaC)
    else:
        var.beta = np.zeros(len(var.mu))
        var.rho = np.zeros(len(var.mu))
    
        

